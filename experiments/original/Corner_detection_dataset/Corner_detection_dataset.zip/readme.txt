Dear users,

These images were collected from the Ineternet:

1. http://www.acclaimimages.com/
2. http://sipi.usc.edu/database/
3. https://www.google.com.au/

If you want to use these images for research purposes only or for any other pruposes, it is your responsibility and do not forget give proper credits to the above websites. 

I do not take any responsibility of misuse or what so ever.

Thanks.

Dr Mohammad Awrangjeb
Monash University, Australia